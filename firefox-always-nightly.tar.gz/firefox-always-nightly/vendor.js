// Disable update check
pref("app.update.enabled", false);
