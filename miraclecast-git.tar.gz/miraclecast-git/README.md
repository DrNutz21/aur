# miraclecast AUR package

build miraclecast from AUR

https://aur.archlinux.org/packages/miraclecast

## Contribute

Submit your contributions to https://github.com/albfan/aur-miraclecast.git
